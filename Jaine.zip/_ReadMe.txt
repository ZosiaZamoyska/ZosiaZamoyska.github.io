-----------------------------------------------------------------------------------------------------------------------
------> INFO
-----------------------------------------------------------------------------------------------------------------------

Template Name: Jaine
Design/Development: templatefoundation.com
License: Free for personal and commercial use under the Creative Commons Attribution 4.0 license


-----------------------------------------------------------------------------------------------------------------------
------> CREDITS
-----------------------------------------------------------------------------------------------------------------------

- jQuery ( https://jquery.com/ )
- Bootstrap ( http://getbootstrap.com/ )
- Google Font Bellafair ( https://fonts.google.com/specimen/Bellefair )
- Font Awesome ( http://fontawesome.io/ )
- Featherlight ( https://noelboss.github.io/featherlight/ )
- Demo Images ( https://pixabay.com/ )